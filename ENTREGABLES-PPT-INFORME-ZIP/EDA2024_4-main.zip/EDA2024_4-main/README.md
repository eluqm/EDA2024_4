# EDA2024_4
# <samp>Diagrama de flujo</samp>

<img src="MaterialesParaElProyecto/MenuFinalizado.jpg" alt="Diagrama">
