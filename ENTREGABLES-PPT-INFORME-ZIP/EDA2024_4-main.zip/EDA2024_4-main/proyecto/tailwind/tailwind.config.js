/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['../app_episound/**/*.{html,js}'],
  theme: {
    extend: {},
  },
  plugins: [],
}